class A {
    public void display() {
        System.out.println("I am in A");
    }
}
class SingleInheritence extends A {
    public void print() {
        System.out.println("I am in B");
    }

    public static void main(String[] args) {
        a12_a w = new a12_a();
        w.display(); 
        w.print();
    }
}
