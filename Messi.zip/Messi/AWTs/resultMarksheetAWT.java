import java.awt.*;
import java.awt.event.*;

public class resultMarksheetAWT extends Frame implements ActionListener {
    private TextField nameField, rollNumberField, subject1Field, subject2Field, subject3Field;
    private Button generateButton;
    private TextArea resultArea;

    public resultMarksheetAWT() {
        setLayout(new FlowLayout());

        Label nameLabel = new Label("Name:");
        nameField = new TextField(20);
        Label rollNumberLabel = new Label("Roll Number:");
        rollNumberField = new TextField(10);

        Label subject1Label = new Label("Subject 1:");
        subject1Field = new TextField(5);
        Label subject2Label = new Label("Subject 2:");
        subject2Field = new TextField(5);
        Label subject3Label = new Label("Subject 3:");
        subject3Field = new TextField(5);

        generateButton = new Button("Generate Mark Sheet");
        generateButton.addActionListener(this);

        resultArea = new TextArea(10, 40);

        add(nameLabel);
        add(nameField);
        add(rollNumberLabel);
        add(rollNumberField);
        add(subject1Label);
        add(subject1Field);
        add(subject2Label);
        add(subject2Field);
        add(subject3Label);
        add(subject3Field);
        add(generateButton);
        add(resultArea);

        setTitle("Mark Sheet Generator");
        setSize(400, 300);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == generateButton) {
            String name = nameField.getText();
            String rollNumber = rollNumberField.getText();
            int subject1Marks = Integer.parseInt(subject1Field.getText());
            int subject2Marks = Integer.parseInt(subject2Field.getText());
            int subject3Marks = Integer.parseInt(subject3Field.getText());

            int totalMarks = subject1Marks + subject2Marks + subject3Marks;
            double averageMarks = (double) totalMarks / 3;

            String markSheet = "Name: " + name + "\n";
            markSheet += "Roll Number: " + rollNumber + "\n";
            markSheet += "Subject 1: " + subject1Marks + "\n";
            markSheet += "Subject 2: " + subject2Marks + "\n";
            markSheet += "Subject 3: " + subject3Marks + "\n";
            markSheet += "Total Marks: " + totalMarks + "\n";
            markSheet += "Average Marks: " + averageMarks + "\n";

            resultArea.setText(markSheet);
        }
    }

    public static void main(String[] args) {
        new resultMarksheetAWT();
    }
}
