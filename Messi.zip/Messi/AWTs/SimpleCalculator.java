import java.awt.*;
import java.awt.event.*;

class SimpleCalculator extends Frame implements ActionListener {
    TextField display;
    double num1, num2;
    char operator;
    Frame f;
    Panel p1,p2;

    SimpleCalculator() {
        f = new Frame();
        f.setTitle("Simple Calculator");
        f.setSize(300, 300);
        f.setLayout(new GridLayout(2, 1));

        p1 = new Panel();
        p1.setLayout(null);
        display = new TextField();
        display.setBounds(50,50,200,30);
        display.setEditable(false);
        p1.setSize(display.getWidth(),display.getHeight());;
        p1.add(display);
        f.add(p1);
        String[] buttonLabels = {
            "7", "8", "9", "/",
            "4", "5", "6", "*",
            "1", "2", "3", "-",
            "0", ".", "=", "+"
        };

        p2 = new Panel();
        p2.setLayout(new GridLayout(4,4));
        for (String label : buttonLabels) {
            Button button = new Button(label);
            button.addActionListener(this);
            p2.add(button);
        }
        f.add(p2);
        
        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(1);
            }
        });

        f.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        
        if (Character.isDigit(command.charAt(0)) || command.equals(".")) {
            display.setText(display.getText() + command);
        } else if (command.equals("=")) {
            num2 = Double.parseDouble(display.getText());
            double result = performOperation(num1, num2, operator);
            display.setText(Double.toString(result));
        } else {
            num1 = Double.parseDouble(display.getText());
            operator = command.charAt(0);
            display.setText("");
        }
    }

    private double performOperation(double a, double b, char op) {
        switch (op) {
            case '+':
                return a + b;
            case '-':
                return a - b;
            case '*':
                return a * b;
            case '/':
                if (b != 0) {
                    return a / b;
                } else {
                    display.setText("Error: Division by zero");
                    return 0;
                }
            default:
                return 0;
        }
    }

    public static void main(String[] args) {
        new SimpleCalculator();
    }
}
