import java.awt.*;
import java.awt.event.*;

class stringOperations extends Frame implements ActionListener {
    Label l_str1, l_str2;
    TextField t_str1, t_str2;
    Button submit;
    TextArea display;

    stringOperations() {
        l_str1 = new Label("String 1");
        l_str2 = new Label("String 2");
        t_str1 = new TextField();
        t_str2 = new TextField();
        submit = new Button("go");
        display = new TextArea("", 2, 100, TextArea.SCROLLBARS_NONE);

        l_str1.setBounds(10, 40, 100, 20);
        t_str1.setBounds(10, 65, 100, 20);
        l_str2.setBounds(120, 40, 100, 20);
        t_str2.setBounds(120, 65, 100, 20);
        submit.setBounds(50, 90, 110, 30);
        display.setBounds(10, 130, 210, 100);
        display.setEditable(false);

        add(l_str1);
        add(l_str2);
        add(t_str1);
        add(t_str2);
        add(submit);
        add(display);

        submit.addActionListener(this);
        setTitle("String Operations");
        setSize(230, 240);
        setLayout(null);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(1);
            }
        });
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submit) {
            if(t_str1.getText().isEmpty() || t_str2.getText().isEmpty()){
                display.setText("");
            }else{
                String str1 = t_str1.getText();
                String str2 = t_str2.getText();

                StringBuilder sb = new StringBuilder(str2);
                sb.reverse();

                String oper = "concat() = " + str1.concat(str2) +
                              "\ntoLowerCase() = " + str1.toLowerCase() +
                              "\ntoUpperCase() = " + str2.toUpperCase() +
                              "\nrim() = " + str2.trim() +
                              "\nreplace(' ', '#') = " + str2.replace(' ', '#') +
                              "\nreverse(): " + sb;

                display.setText(oper);
            }
        }
    }

    public static void main(String[] args) {
        new stringOperations();
    }
}
