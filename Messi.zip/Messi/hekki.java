import java.util.Scanner;
public class hekki{
	public static void main(String[] args)
	{
        String[] array = {"a", "x", "y", "g", "b"};
        Sorts(array);
        System.out.println("Sorted array in alphabetical order:");
        for (String fruit : array) {
            System.out.println(fruit);
        }
    }

    // User-defined bubble sort method
    public static void Sorts(String[] array) {
        int n = array.length;
        boolean swapped;
        for (int i = 0; i < n - 1; i++) {
            swapped = false;
            for (int j = 0; j < n - 1 - i; j++) {
                if (array[j].compareTo(array[j + 1]) > 0) {
                    // Swap elements
                    String temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                    swapped = true;
                }
            }
            // If no two elements were swapped in the inner loop, then the array is already sorted
            if (!swapped) {
                break;
            }
		
	}}
}