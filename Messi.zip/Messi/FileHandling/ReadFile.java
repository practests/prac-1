import java.io.*;
public class ReadFile {
    public static void main(String[] args) {
        try {
            FileReader fr = new FileReader("abc.txt");
            BufferedReader br = new BufferedReader(fr);

            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }

            br.close();
        } catch (IOException ex) {
            System.out.println("Error occurred");
            System.out.println("Exception Name: " + ex);
        }
    }
}
