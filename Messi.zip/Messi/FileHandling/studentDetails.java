import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class studentDetails {
    public static void main(String[] args) {
        try {
            Scanner sc = new Scanner(System.in);

            System.out.print("Enter student name: ");
            String name = sc.nextLine();

            System.out.print("Enter roll number: ");
            String roll = sc.nextLine();

            System.out.print("Enter Standard: ");
            String std = sc.nextLine();

            System.out.print("Enter Division: ");
            String div = sc.nextLine();

            System.out.print("Enter contact number: ");
            String contact = sc.nextLine();

            
            FileWriter writer = new FileWriter("stud.txt", true);
            writer.write("Name: " + name + "\n");
            writer.write("Email: " + roll + "\n");
            writer.write("Branch: " + std + "\n");
            writer.write("Section: " + div + "\n");
            writer.write("Mobile: " + contact + "\n");
            writer.close();

            System.out.println("Student data saved successfully!");
            sc.close();
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
