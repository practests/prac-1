public class a1 {
    public static void main(String args[])
    {
        String a = "Hello";
        String r_a = "";
        
        for (int i = 0; i < a.length(); i++) {
          r_a = a.charAt(i) + r_a;
        }
        System.out.println("original string: "+ a);
        System.out.println("Reversed string: "+ r_a);
                
    }
}