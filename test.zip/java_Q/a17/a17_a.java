abstract class Shape {
    int length;
    int width;
    abstract void printArea();
}

class Rectangle extends Shape {
    Rectangle(int length, int width) {
        this.length = length;
        this.width = width;
    }

    @Override
    void printArea() {
        int area = length * width;
        System.out.println("Area of rectangle: " + area);
    }
}

class Triangle extends Shape {
    Triangle(int length, int width) {
        this.length = length;
        this.width = width;
    }

    @Override
    void printArea() {
        double area = 0.5 * length * width;
        System.out.println("Area of triangle: " + area);
    }
}

class Circle extends Shape {
    Circle(int radius) {
        this.length = radius; 
    }

    @Override
    void printArea() {
        double area = 3.14 * length * length;
        System.out.println("Area of circle: " + area);
    }
}

public class a17_a {
    public static void main(String[] args) {
        new a17_a();
        Rectangle rectangle = new Rectangle(5, 8);
        rectangle.printArea();

        Triangle triangle = new Triangle(4, 6);
        triangle.printArea();

        Circle circle = new Circle(3);
        circle.printArea();
    }
}
