class a {
    public void display() {
        System.out.println("I am in A");
    }
}
class b extends a {
    public void print() {
        System.out.println("I am in B");
    }
}

class c extends b {
    public void show() {
        System.out.println("I am in C");
    }
}

public class a12_c{
    public static void main(String[] args) {
        c e = new c();
        e.display();
        e.print();
        e.show();
    }
}
