interface One {
	public void one();
}

interface Two {
	public void two();
}

interface Three extends One, Two {
	
}
class Four implements Three {
	@Override 
	public void one()
	{
		System.out.println("11111");
	}

	public void two(){ 
		System.out.println("22222"); 
	}
}

public class a12_b {
	public static void main(String[] args)
	{
		Four c = new Four();
		c.two();
		c.one();
	}
}
