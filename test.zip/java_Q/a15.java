import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class a15 extends JFrame implements ActionListener {
    TextField num1, num2, result;
    Frame f;
    public a15() {
        f = new Frame();
        f.setTitle("div");
        f.setSize(300, 200);
        f.setLayout(new GridLayout(1,1));
        

        num1 = new TextField(2);
        num2 = new TextField(2);
        result = new TextField(2);
        result.setEditable(false);

        Button b_div = new Button("Divide");
        b_div.addActionListener(this);

        Panel panel = new Panel();
        panel.setLayout(new GridLayout(4, 2));
        panel.add(new Label("Num1:"));
        panel.add(num1);
        panel.add(new Label("Num2:"));
        panel.add(num2);
        panel.add(new Label("Result:"));
        panel.add(result);
        panel.add(b_div);

        f.add(panel);
        f.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        try {
            int numb1 = Integer.parseInt(num1.getText());
            int numb2 = Integer.parseInt(num2.getText());

            if (numb2 == 0) {
                throw new ArithmeticException("Division by zero");
            }

            float res = (float)numb1 / numb2;
            result.setText(Float.toString(res));
        } catch (NumberFormatException ex) {
           result.setText("invalid input"); 
        } catch (ArithmeticException ex) {
            result.setText("cannot divide by zero");
        }
    }

    public static void main(String[] args) {
        new a15();
    }
}
