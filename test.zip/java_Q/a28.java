import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

class a28 extends Frame {
    Frame f;
    Panel p1,p2;
    a28() {
        f = new Frame();
        f.setTitle("Table");
        f.setSize(300,300);
        f.setLayout(new GridLayout(2,1)); 
        f.setVisible(true);

        try {
            BufferedReader reader = new BufferedReader(new FileReader("Table.txt"));
            String headerLine = reader.readLine(); 
            String[] headers = headerLine.split(","); 

            p1 = new Panel();
            p1.setLayout(new GridLayout(1,3));
            for (String header : headers) {
                p1.add(new Label(header));
            }

            f.add(p1);
            
            p2 = new Panel();
            p2.setLayout(new GridLayout(4, 3));
            String dataLine;
            while ((dataLine = reader.readLine()) != null) {
                String[] rowData = dataLine.split(",");
                
                for (String value : rowData) {
                    p2.add(new Label(value));
                }
            }
            f.add(p2);
            reader.close();
        } catch (IOException e) {
            System.err.println("Error reading data from file: " + e.getMessage());
        }

        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }

    public static void main(String[] args) {
        new a28();
    }
}
