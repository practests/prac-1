public class a10 {
   public static void main(String[] args) {
      int num = 101010101;
      String a = Integer.toString(num);
      String r_a = "";
      
      for (int i = 0; i < a.length(); i++) {
          r_a = a.charAt(i) + r_a;
      }

      int r_num = Integer.parseInt(r_a);
      if (num == r_num) {
        System.out.println(num + " is a palindrome number!!");
      }else{
        System.out.println(num + " is not a palindrome number");
      }

   } 
}
