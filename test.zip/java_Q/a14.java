class a14 implements Runnable {
    Thread t;

    a14() {
        t = new Thread(this);
        System.out.println("Thread is in new state");
    }

    public void run() {
        System.out.println("Thread is in runnable state");
        
        System.out.println("Thread execution completed");
    }

    public static void main(String[] args) {
        a14 child = new a14();
        child.t.start();
    }
}
