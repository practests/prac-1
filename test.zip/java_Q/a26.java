import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class a26 extends Frame implements ActionListener {
     TextField t_name, t_roll;
     TextField[] t_sub;
     Label l_tmrks, l_per;
     Panel p1,p2,p3,p4,p5,p6,p7,p8;
     Frame f;

    public a26() {
        f = new Frame();
        f.setTitle("Mark Sheet");
        f.setSize(400,400);
        f.setLayout(new GridLayout(8, 1));

        p1 = new Panel();
        p1.setLayout(new GridLayout(1,2));
        Label l1 = new Label("Student Name:");
        t_name = new TextField();
        p1.add(l1);
        p1.add(t_name);
        f.add(p1);


        p2 = new Panel();
        p2.setLayout(new GridLayout(1,2));
        Label l2 = new Label("Roll Number:");
        t_roll = new TextField();
        p2.add(l2);
        p2.add(t_roll);
        f.add(p2);


        p3 = new Panel();
        p3.setLayout(new GridLayout(6,2));
        Label l3 = new Label("Enter Marks for Subjects:");
        f.add(l3);
        t_sub = new TextField[6];
        for (int i = 0; i < 6; i++) {
            t_sub[i] = new TextField();
            t_sub[i].setSize(100, 20);
        }

        Button calc = new Button("Calculate");
        calc.addActionListener(this);

        l_tmrks = new Label("Total Marks:");
        l_per = new Label("Percentage:");

        for (int i = 0; i < 6; i++) {
            p3.add(new Label("Subject " + (i + 1) + ":"));
            p3.add(t_sub[i]);
        }
        f.add(p3);
        f.add(calc);
        f.add(l_tmrks);
        f.add(l_per);

        f.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        int totalMarks = 0;
        for (int i = 0; i < 6; i++) {
            totalMarks += Integer.parseInt(t_sub[i].getText());
        }

        double percentage = (totalMarks / 600.0) * 100;

        l_tmrks.setText("Total Marks: " + totalMarks);
        l_per.setText("Percentage: " + String.format("%.2f", percentage) + "%");
    }

    public static void main(String[] args) {
        new a26();
    }
}
