import java.awt.*;
import java.awt.event.*;

class a27 extends Frame implements ActionListener {
    Label l_input, l_result;
    TextField t_input, t_result;
    Button compute;
    Frame f1,f2;

    a27() {
        f1 = new Frame();
        f1.setTitle("Factorial Calculator");
        f1.setSize(350, 200);
        f1.setVisible(true);
        f1.setLayout(null);

        l_input = new Label("Enter an integer:");
        l_input.setBounds(50, 50, 100, 30);
        t_input = new TextField();
        t_input.setBounds(200, 50, 100, 30);

        
        compute = new Button("Compute");
        compute.setBounds(130, 100, 100, 30);
        compute.addActionListener(this);

        
        f1.add(l_input);
        f1.add(t_input);
        f1.add(compute);


        f1.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == compute) {
            f2 = new Frame("answer");
            f2.setSize(350, 200);
            f2.setVisible(true);
            f2.setLayout(null);

            l_result = new Label("Factorial result:");
            l_result.setBounds(50, 50, 100, 30);
            t_result = new TextField();
            t_result.setBounds(200, 50, 100, 30);

            t_result.setEditable(false);

            f2.add(l_result);
            f2.add(t_result);

            f2.addWindowListener(new WindowAdapter() {
                public void windowClosing(WindowEvent e) {
                    System.exit(0);
                }
            });

            try {
                int inputNumber = Integer.parseInt(t_input.getText());
                long factorial = Factorial(inputNumber);
                t_result.setText(Long.toString(factorial));
            } catch (NumberFormatException ex) {
                t_result.setText("Invalid input");
                t_result.setForeground(Color.RED);
            }
        }
    }

    private long Factorial(int n) {
        if (n < 0) {
            return 0;
        }
        long result = 1;
        for (int i = 2; i <= n; i++) {
            result *= i;
        }
        return result;
    }

    public static void main(String[] args) {
        a27 a = new a27();
    }
}
